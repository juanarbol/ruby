require 'test_helper'

class EntrollmentsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
