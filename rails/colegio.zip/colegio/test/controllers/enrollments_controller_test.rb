require 'test_helper'

class EnrollmentsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
