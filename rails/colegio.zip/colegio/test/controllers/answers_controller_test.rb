require 'test_helper'

class AnswersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
