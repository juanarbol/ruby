class Teacher < ActiveRecord::Base
	belongs_to :subject
end
