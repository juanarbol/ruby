class Homework < ActiveRecord::Base
	belongs_to :subject
end
